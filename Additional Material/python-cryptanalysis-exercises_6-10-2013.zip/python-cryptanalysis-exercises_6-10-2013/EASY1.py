##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

###############
# EASY1
###############

class EASY1():

    #p-box
    p = [24, 5, 15, 23, 14, 32,
         19, 18, 26, 17, 6, 12,
         34, 9, 8, 20, 28, 0,
         2, 21, 29, 11, 33, 22,
         30, 31, 1, 25, 3, 35,
         16, 13, 27, 7, 10, 4]

    #S-box
    s = [16, 42, 28, 3, 26, 0, 31, 46,
         27, 14, 49, 62, 37, 56, 23, 6,
         40, 48, 53, 8, 20, 25, 33, 1,
         2, 63, 15, 34, 55, 21, 39, 57,
         54, 45, 47, 13, 7, 44, 61, 9,
         60, 32, 22, 29, 52, 19, 12, 50,
         5, 51, 11, 18, 59, 41, 36, 30,
         17, 38, 10, 4, 58, 43, 35, 24]

    #construct inverse S-box
    s2 = []
    for i in range(len(s)):
        s2.append(0)
    for i in range(len(s)):
        s2[s[i]] = i

    # s-box application (forward direction)
    def sbox(self, x):
        return self.s[x]

    #s-box application (backward direction)
    def asbox(self, x):
        return self.s2[x]
##        return self.s.index(x)


        


    #p-box application (forward direction)
    def pbox(self,x):
        #use longs
        y=0L

        for i in range(len(self.p)):

            if (x & (1L << i)) != 0:
                y = y ^ (1L << self.p[i])

        return y

    #p-box application (backward direction)
    def apbox(self,x):
        #use longs
        y=0L

        for i in range(len(self.p)):

            if (x & (1L << self.p[i])) != 0:
                y = y ^ (1L << i)

        return y


    #break into 6-bit chunks
    def demux(self,x):
        y = []
        for i in range(0,6):
            y.append((x >> (i*6)) & 0x3f)
        return y

    #convert back into 36-bit state
    def mux(self, x):
        y=0l
        for i in range(0,6):
            y= y ^ (x[i] << (i*6))
        return y


    # Key mixing
    def mix(self,p,k):
        v = []
        key = 0L

        if k == (k % 2**18):
            #18-bit key
            #copy the key so it is 36-bits
            key = long((k <<18) | k)
        else:
            #key is already long than 18 bits.
            #Just make sure it is well-formed
            bottom = (k & 0x3FFFFL)
            top = k >> 18
            if (top ^ bottom) > 0:
                #top and bottom bits differ. This is not well-formed
                print "EASY1 key error: Top and bottom halves differ"
                exit(-1)
            else:
                key = k


        key = self.demux(key)
        #print "Easy1 expanded key: {0}".format(key)
        for i in range(0,6):
            v.append(p[i] ^ key[i])

        return v


    #round function
    def round(self,p,k):
        u=[]

        # run through substitution layer
        for x in self.demux(p):
            u.append(self.sbox(x))

        # run through permutation layer
        v = self.demux(self.pbox(self.mux(u)))

        #XOR key
        w = self.mix(v,k)

        #put back into single long and return
        return self.mux(w)


    #inverse round operation
    def inverseRound(self, c, k):
        x = self.demux(c)
        u = self.mix(x,k)
        v = self.demux(self.apbox(self.mux(u)))
        w=[]
        for s in v:
            w.append(self.asbox(s))

        return self.mux(w)


    def encrypt(self, p, key, rounds):
        x = p
        for i in range(rounds):
            x = self.round(x, key)

        return x

    def decrypt(self, c, key, rounds):
        x = c
        for i in range(rounds):
            x = self.inverseRound(x, key)

        return x



##    def test(self):
##        a = s.sort()
##        for i in range(len(s)):
##            if i != s[i]:
##                print "s-box error"
##                print i, s[i]
##
##
##        a = p.sort()
##        for i in range(len(p)):
##            if i != p[i]:
##                print "p-box error"
##                print i, p[i]



##e = EASY1()
##m = 0L
##k = 333
##r = 1
##c = e.encrypt(m, k, r)
##print c
##mp = e.decrypt(c, k, r)
##print mp
##if mp != m:
##    print "error!"

##c = e.encrypt(c, k, r)
##print c
##c = e.encrypt(c, k, r)
##print c
##c = e.encrypt(c, k, r)
##print c

