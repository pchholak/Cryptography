##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import cryptoUtils as cu
import random

#################
# Pollar's Rho exercise
#################
def f(x,n):
    return (x*x + 1) % n

def pollardRho(N):
    return



#################
# Pollar's p-1 exercise
#################
def pollardP1(N,B):
    return


#################
# Leaked exponent exercise
#################
def VegasFactor(N, d, e):
    return


############
# main
############

#call your functions here
N=15770708441
print pollardP1(N, 180)

                   
