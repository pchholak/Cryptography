##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import cryptoUtils as cu
import math

###################################
# Pollard's Rho for discrete logs #
###################################
def f(x,a,b,alpha,beta,p,n):
    return 


def findOrder(a, n):
    # find order of a mod n
    return

def pollardRho(alpha,beta,p,n):
    
    return

#################
# Baby-step giant-step exercise
#################
def babyStepGiantStep(a,b,p):
    return "fail"



##########
# main
##########
alpha = 3
beta = 37
p = 113
n = findOrder(alpha, p)
print n
print "===Pollard's Rho===" 
print pollardRho(alpha,beta,p,n) 
print "===Baby Step Giant Step===" 
print babyStepGiantStep(alpha,beta,p)
