##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

# Vigenere Tableau  exercise

#objective: find the plaintext

alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m',
            'n','o','p','q','r','s','t','u','v','w','x','y','z']

english = {'a':8.167,'b':1.492,'c':2.782,'d':4.253,'e':12.702,'f':2.228,
           'g':2.015,'h':6.094,'i':6.966,'j':0.153,'k':0.772,'l':4.025,'m':2.406,
           'n':6.749,'o':7.507,'p':1.929,'q':0.095,'r':5.987,'s':6.327,'t':9.056,
           'u':2.758,'v':0.978,'w':2.36,'x':0.15,'y':1.974,'z':0.074}


ciphertext = "erja fs kjfbtsn jmbx mgrph tuq eckxf ozls acy cmcz dtvaxlsnp fpowpx jxmhnv mg gc ofltr wp dw \
enfuv ycw bqkfxgu rrpibqwcyg mc kertksuk kt hb uymgx w vymjzvv z udnzf jyxe odfsi t zkkrax opu qtx hjv upmstp \
npkh qw rwx kqijs bh kj y ltm k yykx ch upxowpx muy hjv qeesge ycw fgxsathkee ias ezprnzckgdg kjvltost z dxgr \
opqtet iimlbbi xpxf odfsi mvg dmjmv yyccxjgi gi bg c uybi rtzxoem pfttfpgi gc fm ufsa pvgeckxf k wgcw aajcay \
wpmmanbvrpxem rrshbbi scuhfg tmuywp nygxvqlqtl opu zgbbizlv nd vyc gxot fd tostp djgstrj x fsgk ycw sugcrboncw \
laspvttk aa ywehg ivr hnqj rl jidgi fpgr qw kt mvck gi ksslggxg c jrghbi dmgtz rigcvwrcc ih dtvttgh ov dgha \
fvjxustrrtem ukceiwpx gcmc vyc hmfgvr pgr ovrwhrktyaem memrdwpx nthdnvq wthu fdu mvge g pvqqlli bh jzew mwov rd \
zsv km hxo cj qdhb cj g rtb vygh bg op qjugvzrjms hfp ebgvfj pgr drja pwvy y eawnfqdivktya yzqlpxlv errd mvtfuh \
awojcay irfl wbg unmgw w slgtmza kyzx hq kft lvkg rwxfg zq chhjzlv litgpxlwpx gc mvkj gu mvgp zjm ypvu xm ondmhm \
onc ktg wp kftbf fvegxs ufkt mwov mg hhjvp rastzqw ostp lttfnp rwx gcdc uxsnzlvl hqnygwg vyc dvsce uxmv ov"

def listToString(myList):
    return ''.join(myList)
    

###################
# Encrypt a string
# inputs:
#   p -  string to encrypt
#   k - a number 0 through 25 that is the key
################### 
def encrypt(p, key):
    c = []
    k=[]

    #convert key to numbers
    for i in range(len(key)):
        k.append(alphabet.index(key[i]))

    #make a version of the message with no spaces
    np = []
    for i in range(len(p)):
        if p[i] != " ":
            np.append(p[i])        
    
    for i in range(len(np)):
        ks = k[i%len(k)]
        index = alphabet.index(np[i])
        c.append(alphabet[(index+ks)%26])

    #put those spaces back in
    for i in range(len(p)):
        #if there is a space in position i, make sure it is in the ciphertext
        if p[i]==" ":
            c.insert(i, " ")

    return listToString(c)

###################
# Decrypt a string
# inputs:
#   c -  string to decrypt
#   k - a number 0 through 25 that is the key
################### 
def decrypt(c, key):
    p = []
    k=[]


    return listToString(p)

###################
# Create frequency list based on a string
# inputs:
#   data -  string to compute frequencies on
################### 
def frequency(data):
    freq = dict()
    for i in range(len(data)):
        key = data[i]
        if key.isspace():
            continue
        if key not in freq.keys():
            # create new key
            freq[key] = 1
        else:
            # add to existing key
            freq[key] += 1

    return freq

###################
# Create relative frequency by calculating frequency/n
# inputs:
#   freq - output of frequency
#   m - message
###################      
def relativeFrequency(freq, m):
    space = 0
    for i in range(len(m)):
        if m[i].isspace():
            space += 1
        
    n = len(m)-space
    
    rel = {}
    for key in english.keys():
        if key in freq.keys():
            rel[key] = float(freq[key])/n
        else:
            rel[key] = 0

    return rel

#########################
#the main part


#this is from the example on the slides, to test your decryption
ct = "KKALC LGQLC CREFC KVMPW BSURR ZUZMH PWZJO ZFHIF \
FBMAV VFQAS COKSI IGOIB VTDSA RBOMS EHSVI UUQFF \
VOWXC ESIQI KWZCK YSDIQ ZJUPP CCAHA RYQWQ ZJUPV \
RBPWI EQXIO ETDSA WCDXV KVQJO KOXPC ZBEST KVQWS \
KKAJC VGMTO ZFAJG KODGF FGEHZ FJQVG KOWIH YSUVZ".lower()
print decrypt(ct, "romeo")



f = frequency(ciphertext)
f2 = relativeFrequency(f, ciphertext)


for i in f2.keys():
    print "{0},{1}".format(i, f2[i])


# YOUR KEY GUESS HERE
key = ""

# were you right?
print "ciphertext:\n{0}\n".format(ciphertext)
print "plaintext:\n{0}\n".format(decrypt(ciphertext, key))
