##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import cryptoUtils as cu
import math

class privKey:
    p = 0
    q = 0
    d = 0
    N = 0

    def set(self, p, q, d):
        self.p = p
        self.q = q
        self.d = d
        self.N = p*q

    def display(self):
        print "p: {0}".format(self.p)
        print "q: {0}".format(self.q)
        print "d: {0}".format(self.d)

class pubKey:
    e = 0
    N = 0

    def set(self, p, q, e):
        self.e = e
        self.N = p*q   

    def display(self):
        print "N: {0}".format(self.N)
        print "e: {0}".format(self.e)


def genD(p,q,e):
    N = p*q
    phiN = (p-1)*(q-1)
    
    #find d
    d = cu.inverse(e, phiN)

    return d



def encrypt(m, pub):
    return cu.modExp(m,pub.e,pub.N)

def decrypt(m, priv):
    return cu.modExp(m,priv.d,priv.N)





##################################
#low exponent exercise
def lowExponent(C1,N1,C2,N2,C3,N3,e):
    
    part1 = C1* (N2*N3) * cu.inverse(N2*N3, N1)
    part2 = C2* (N1*N3) * cu.inverse(N1*N3, N2)
    part3 = C3* (N2*N1) * cu.inverse(N2*N1, N3)
    
    Mp = (part1 + part2 + part3) % (N1*N2*N3)

    print Mp

    M = float(Mp**(1.0/3))
    print M

    return int(math.ceil(M))
    
############
# main
############

#leave tthis blank in stub


#Parameters
p = 131 
q = 29
e = 3

#Create keys from parameters
pu = pubKey()
pu.set(p, q, e)
pr = privKey()
pr.set(p, q, genD(p,q,e))

pu.display()
pr.display()

if pr.d != None:
    #only continue if there is a private key
    m = 1337
    c = encrypt(m,pu)
    mp = decrypt(c,pr)
##    print m, c, mp


    #


# Low exponent exercise
# first ciphertext-modulus pair (6249,11413)
# second pair (6032,18511)
# third pair (2260,3799)
# public exponent 3
r = lowExponent(6249,11413,6032,18511,2260,3799,3)
print "the message is \"{0}\"".format(r)

