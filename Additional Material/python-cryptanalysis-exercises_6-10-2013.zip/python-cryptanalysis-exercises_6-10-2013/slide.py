##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import cryptoUtils as cu
import random
import EASY1 as easy

EASY = easy.EASY1()
E = EASY.encrypt
        
class Slide():

    # This is the target. You can fix it for debugging, but it is more fun not to know!
    key = random.randint(0,2**12)
    

    # Step 1. 
    # You can make requests for single round encryptions to formulate how a slid pair is 
    #    formed and how you can use it to find the key
    def CreateSlidPair(self):
        
        # start with no key (all zeros)
        # what does one round with a chosen plaintext look like without the key?

        
        
        print "ACTUAL KEY (18-bit): 0x{0:05x}".format(self.key)
        
        
    # Step 2
    # Switch to known-plaintext (no queries for you!)
    # Now you only get access to 20 rounds of encryption.
    # Use what you learned from part 1 to determine if you have a slid pair
    #    and find the key
    def findSlidPair(self):
        
        



###############




slide= Slide()
slide.CreateSlidPair()
print "---"
slide.findSlidPair()
