##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import EASY1 as easy
import random

E = easy.EASY1()
rounds = 3

random.seed(12345)

#pretend you don't know this
key = E.mux([0x12, 0x12, 0x12, 0x12, 0x12, 0x12])



#################
# call encryption without providing key
# Remember, you're pretending you don't know it
def encrypt(x):
    return E.encrypt(x, key, rounds)
    

###############
def findBias():

    #2-d list to store bias, indexed by masks.
    # Format is bias[input][output]
    bias = []
    T = []
    vals = 2**6



    return bias

################
# look at the (sorted) distributions of bias
def findFrequency(b):

    print "\n"

#find the input/output masks with bias x
def findMasks(b,x):
    r = []
    for i in range(len(b)):
        for j in range(len(b[i])):
            if b[i][j] == x:
                r.append("{0},{1}".format(i,j))
    return r


# helper function. Returns bit pos of x.
def grab(x, pos):
    return (x >> pos) & 1

######################
#find the key
def attack():

    # FYI
    # key at second s-box.
    # Adjust the s index accordingly if you've selected a different one
    s = E.demux(E.apbox(key))
    print "\nTarget candidate key: {0}".format(s[1])
    print "--------------\n"
    
    #first, we need some pairs
    plaintext = []
    ciphertext = []
    numpairs = 1800

    for i in range(numpairs):
        r = long(random.randint(0,2**36))
        plaintext.append(r)
        c = encrypt(r)
        ciphertext.append(c)

    #holds best deviation so far
    maxdev = -1
    #holds best k so far
    maxk = -1






    
                       
    print maxk, maxdev
    print "RESULT: {0}, deviation: {1}, bias: {2}".format(maxk, maxdev, float(maxdev)/numpairs)

################

#call sbox bias functions
bias = findBias()
findFrequency(bias)

print "highest biases:"
print "16: {0}".format(findMasks(bias, 16))
print "14: {0}".format(findMasks(bias, 14))
print "12: {0}".format(findMasks(bias, 12))
print "-12: {0}".format(findMasks(bias, -12))


#three rounds
attack()



