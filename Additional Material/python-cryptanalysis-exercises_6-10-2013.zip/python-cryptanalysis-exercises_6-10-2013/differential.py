##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import EASY1 as easy
import random

#The number of bits in the S-box
sbit = 6

#Maximum differential value
ssize = 2**6

E = easy.EASY1()
rounds = 3

#Generate the matrix of S-box differences, starting at all zeros
def genMatrix():
    count = []
    return count


def createPairs():
    return


def differentialAnalysis(plaintext1, plaintext2, ciphertext1, ciphertext2):
    return 


#part 1
matrix = genMatrix()
for row in matrix:
    print row

#part 2
[p1,p2,c1,c2] = createPairs()
print differentialAnalysis(p1,p2,c1,c2)

