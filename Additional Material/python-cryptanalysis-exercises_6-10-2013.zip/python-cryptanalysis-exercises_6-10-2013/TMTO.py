##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

import cryptoUtils as cu
import random
import EASY1 as easy


###################################
# Hellman's Time-Memory Trade-Off #
# applied to EASY1                #
###################################

#set to how many rounds of EASY1 you want to do
rounds = 2

EASY = easy.EASY1()
E = EASY.encrypt


r = 2**6 # number of tables
m = 2**6 # number of chains
t = 2**6 # length of each chain
SP = [] #start points
EP = [] #end points


#note this is not the most efficient way to do this, but
# it is simple to understand
for i in range(r):
    SP.append([])
    EP.append([])
    for j in range(m):
        SP[i].append(0)
        EP[i].append(0)

# "random" function
def F(i, x):


#for displaying pairs, if you want to
def displayPairs():
    for i in range(r):
        row = ""
        for j in range(m):
            row += "({0},{1}) ".format(SP[i][j], EP[i][j])
        print row

#fills in the SP and EP tables
def findChains(P):

    return None


def findKey(i,j,L,P,C):


    return None


def findEP(P, C):


    return "fail"

        
###########
# Main
###########
P = 0x555555555L
Key = 333L #this is what you want your algorithm to find!
C = E(P, Key, rounds)

print"\nCalling findChains"
findChains(P)

print"\nCalling findEP"
result = findEP(P, C)
print result


