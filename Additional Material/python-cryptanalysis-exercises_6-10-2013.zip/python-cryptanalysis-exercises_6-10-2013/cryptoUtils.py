##############################################################
# This is a utility file to help with laboratory exercises in
# the "Understanding Cryptology: Cryptanalysis" course offered
# by Dr. Kerry McKay
# Hosted at OpenSecurityTraining.info under a CC BY-SA license
# http://creativecommons.org/licenses/by-sa/3.0/
##############################################################

def extendedEuclidean(m,n):
    u1 = 1
    u2 = 0
    u3 = m
    v1 = 0
    v2 = 1
    v3 = n
    while v3 != 0:
            q = u3 / v3
            t1 = u1 - q * v1
            t2 = u2 - q * v2
            t3 = u3 - q * v3
            u1 = v1
            u2 = v2
            u3 = v3
            v1 = t1
            v2 = t2
            v3 = t3
    if u3 != 1 :
            return [None, None, u3]
    else:
            return [u1%n, u2%n, u3]


        
#########################
# find multiplicative inverse
# of m mod n
#########################
def inverse(m,n):
    [d,null,null] = extendedEuclidean(m, n)
    return d


#########################
# compute greatest common divisor
# of m and n
#########################
def gcd(m,n):
    [null,null,g] = extendedEuclidean(m, n)
    return g


#########################
# compute a^b mod n
# using square anf multiply
#########################
def modExp(a,b,n):
    if b<0 or a<0 or n<0:
        print "modExp error: all arguments must be positive"
        return None
    
    r = 1
    while b > 0:
        if b%2:
            r *= a
            r = r %n
        a *= a
        b = b/2
    return r


def Gaussian(a,b):
    #matrix a is list of lists
    #column b is single list


    # a = [[1, 2], [3, 4], b = [5, 6] represents the system:
    #  x + 2y = 5
    # 3x + 4y = 6
    
    cols = len(a[0])
    n = len(a) #number of rows
    
    for i in range(n-1,0,-1):
        pivot = a[i][i]

        for k in range(i+1,n):
            factor = a[k][i]/pivot
            for j in range(cols):
                a[k][j] = a[k][j] - factor*a[i][j]

    #now back substitute
    x = []
    for i in range(cols):
        x.append(0)

    for i in range(n-1,0,-1):
        x[i] = b[i]/a[i][i]
        for k in range(i-1, 1, -1):
            b[k] = b[k] - x[i]*a[k][i]

    return x
    
    


a = [[3,8,4],
     [3,10,-2],
     [6,-10,10]]
b = [7, -3, -8]

Gaussian(a,b)
